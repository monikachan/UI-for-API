from django.contrib import admin
from django.urls import path, include
from rest_framework.schemas import get_schema_view

from rest_framework_swagger.renderers import SwaggerUIRenderer, OpenAPIRenderer

schema_view = get_schema_view(title='Weather Forecast API', renderer_classes=[OpenAPIRenderer, SwaggerUIRenderer])


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('weatherapi.urls')),
    path('swagger/', schema_view),
    path('', include('APIInterface.urls')),
]
