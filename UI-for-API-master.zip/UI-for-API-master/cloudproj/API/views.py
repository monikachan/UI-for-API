from django.urls import path
from . import views
from django.shortcuts import render

def index(request):
    try:
        return render(request, 'index.html')
    except SyntaxError:
        return('')

def index1(request):
    try:
        return render(request, 'index1.html')
    except SyntaxError:
        return('')


                           
